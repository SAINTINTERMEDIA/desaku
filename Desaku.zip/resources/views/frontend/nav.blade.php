<div class="navigation">
    <nav>
      <ul class="nav topnav">
        <li class="dropdown">
          <a href="index.php">Home</a>
        </li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Profil Desa
<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="?page=overview">Sejarah Desa</a></li>
            <li><a href="?page=profildesa">Profil Wilayah Desa</a></li>
            <li><a href="base-css.php">Arti Lambang Desa</a></li>
            <!--li><a href="components.php">Components</a></li>
            <li><a href="javascript.php">Javascripts</a></li>
            <li><a href="icons.php">More icons</a></li>
            <li class="dropdown"><a href="#">3rd level</a>
              <ul class="dropdown-menu sub-menu">
                <li><a href="#">Example menu</a></li>
                <li><a href="#">Example menu</a></li>
                <li><a href="#">Example menu</a></li>
              </ul>
            </li--->
          </ul>
        </li>
        <li class="dropdown">
          <a href="#">Pemerintahan Desa</a>
          <ul class="dropdown-menu">
            <li><a href="about.php">Visi Misi</a></li>
            <li><a href="pricingtable.php">Pemerintah Desa</a></li>
            <li><a href="fullwidth.php">Badan Permusyawaratan Desa</a></li>
            <!--li><a href="404.php">404</a></li-->
          </ul>
        </li>
        <li class="dropdown">
          <a href="#">LemMas</a>
          <ul class="dropdown-menu">
            <li><a href="portfolio-2cols.php">LPM</a></li>
            <li><a href="portfolio-3cols.php">Karang Taruna</a></li>
            <li><a href="portfolio-4cols.php">PKK</a></li>
            <!--li><a href="portfolio-detail.php">Portfolio detail</a></li-->
          </ul>
        </li>
        <li class="dropdown">
          <a href="#">Data Desa</a>
          <ul class="dropdown-menu">
            <li><a href="blog_left_sidebar.php">Data Wilayah Adminsitratif</a></li>
            <li><a href="blog_right_sidebar.php">Data Pendidikan Dalam KK</a></li>
            <li><a href="post_left_sidebar.php">Data Pendidikan Ditempuh</a></li>
            <li><a href="post_right_sidebar.php">Data Pekerjaan</a></li>
             <li><a href="blog_left_sidebar.php">Data Jenis Kelamin</a></li>
            <li><a href="blog_right_sidebar.php">Data Golongan Darah</a></li>
            <li><a href="post_left_sidebar.php">Data Kelompok Umur</a></li>
            <li><a href="post_right_sidebar.php">Data Perkawinan</a></li>
          </ul>
        </li>
        <li>
          <a href="contact.php">PPID</a>
        </li>
        <li class="dropdown">
          <a href="#">Transparansi Keuangan</a>
          <ul class="dropdown-menu">
            <li><a href="blog_left_sidebar.php">Blog left sidebar</a></li>
            <li><a href="blog_right_sidebar.php">Blog right sidebar</a></li>
            <li><a href="post_left_sidebar.php">Post left sidebar</a></li>
            <li><a href="post_right_sidebar.php">Post right sidebar</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#">Defnaker Desa</a>
          <ul class="dropdown-menu">
            <li><a href="blog_left_sidebar.php">Blog left sidebar</a></li>
            <li><a href="blog_right_sidebar.php">Blog right sidebar</a></li>
            <li><a href="post_left_sidebar.php">Post left sidebar</a></li>
            <li><a href="post_right_sidebar.php">Post right sidebar</a></li>
          </ul>
        </li>
      </ul>
    </nav>
  </div>
  <!-- end menu -->