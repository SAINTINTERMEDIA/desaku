<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Familycards;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
       // $kk = Familycards::groupby('kk')->paginate();
       $kk = Familycards::groupBy('kk')
       ->selectRaw('count(*) as total, kk')
       ->get();
       
       $nik = DB::table('familycards')->paginate();
       $perempuan = Familycards::where('jenis_kelamin','PEREMPUAN')->get();
       $laki2 = Familycards::where('jenis_kelamin','LAKI LAKI')->get();

       $data= [
           'kk'=>$kk,
           'nik'=>$nik,
           'perempuan'=>$perempuan,
           'laki2'=>$laki2
       ];


       return view('layout.cont',$data);

    }
        /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function adminhome()
    {
        return view('frontend.index');
    }
}
