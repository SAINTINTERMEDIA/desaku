<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

use App\Familycards;

use PDF;

use Illuminate\Http\Request;

class FamilycardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

       // return view('familycards.index');
         $familycards = DB::table('familycards')->paginate(10);
         // $familycards = Familycards::all(); 
       return view('familycards.index',['familycards'=> $familycards]);
    }
    public function cetak_pdf()
    {
    	$familycards = Familycards::where('jenis_kelamin','LAKI LAKI')->get();
 
    	$pdf = PDF::loadview('familycards.pdf',['familycards'=>$familycards])->setPaper('a4', 'landscape');
    	//return $pdf->download('laporan-pegawai-pdf');
        return $pdf->stream();
    }

    public function cari(Request $request)
    {
        //menangkap data pencarian
        $cari=$request->cari;

        //mengambil data dari tabel familycards  sesuai pencarian data
        $familycards=DB::table('familycards')
        ->where('nama','like',"%".$cari."%")
        ->paginate(10);

        //mengirim data familycards ke view index
        return view('familycards.index',['familycards'=>$familycards]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('familycards.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
          // validasi
          $request->validate([
            'kk' => 'required',
            'nik'  => 'required|size:9',
            'nama'=> 'required',
            'tempat_lahir'=> 'required',
            'tgl_lahir'=> 'required',
            'status_perkawinan'=> 'required',
            'jenis_kelamin'=> 'required',
            'alamat'=> 'required',
            'rt'=> 'required',
            'rw'=> 'required'
            

        ]);
          //CARA KE TIGA
          familycards::create($request->all());
          return redirect('/family')->with('status','Data KK Berhasil Ditambahkan!');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Familycards  $familycards
     * @return \Illuminate\Http\Response
     */
    public function show(Familycards $familycard)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Familycards  $familycards
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

          $familycards = familycards::find($id);
        return view('familycards.edit',compact('familycards'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Familycard  $familycards
     * @return \Illuminate\Http\Response
     */
    public function update($id, Request $request)
    {
        $this->validate($request,[
            'kk' => 'required',
            'nik'  => 'required|size:9',
            'nama'=> 'required',
            'tempat_lahir'=> 'required',
            'tgl_lahir'=> 'required',
            'status_perkawinan'=> 'required',
            'jenis_kelamin'=> 'required',
            'alamat'=> 'required',
            'rt'=> 'required',
            'rw'=> 'required'
        ]);
     
        $familycard = Familycards::find($id);
        $familycard->kk = $request->kk;
        $familycard->nik = $request->nik;
        $familycard->nama = $request->nama;
        $familycard->tempat_lahir = $request->tempat_lahir;
        $familycard->tgl_lahir = $request->tgl_lahir;
        $familycard->status_perkawinan = $request->status_perkawinan;
        $familycard->jenis_kelamin = $request->jenis_kelamin;
        $familycard->alamat = $request->alamat;
        $familycard->rt = $request->rt;
        $familycard->rw = $request->rw;
        $familycard->save();
        return redirect('/family')->with('status','Data KK Berhasil Di Ubah!');
    }

    public function delete($id)
        {
            $familycard = Familycards::find($id);
            $familycard->delete();
            return redirect('/family')->with('status','Data KK Berhasil Di Hapus!');
        }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Familycard  $familycard
     * @return \Illuminate\Http\Response
     */

    public function destroy(Familycard $familycard)
    {
        //
    }
}
