<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Familycards;

class ControllerFrontend extends Controller
{
    public function index()
    {    

        return view('frontend.index');

    }
    public function cek()
        {
           // $kk = Familycards::groupby('kk')->paginate();
            $kk = Familycards::groupBy('kk')
            ->selectRaw('count(*) as total, kk')
            ->get();
            
            $nik = DB::table('familycards')->paginate();
            $perempuan = Familycards::where('jenis_kelamin','PEREMPUAN')->get();
            $laki2 = Familycards::where('jenis_kelamin','LAKI LAKI')->get();

            $data= [
                'kk'=>$kk,
                'nik'=>$nik,
                'perempuan'=>$perempuan,
                'laki2'=>$laki2
            ];


            return view('layout.cont',$data);
        }
    
}
